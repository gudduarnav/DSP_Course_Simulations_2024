%%
% load handel.mat;

%%
[y,Fs] = audioread('guitar4.wav'); % Read WAV file
soundsc(y,Fs); % Play WAV file

% plot(y);


%% 
close all
L = length(y) ;     % get the length of the sound
figure(1) 
subplot(2,1,1)
plot((1:L)/Fs,y) ;  % plot the waveform
xlabel('sec') ;    
ylabel('y(t)') ;
ylim([-1,1]) ;      % set the range 
hold on
plot(33001*ones(21,1)/Fs,[-1:0.1:1],'r-')
plot(34985*ones(21,1)/Fs,[-1:0.1:1],'r-')


%%
subplot(2,1,2)
index = 33001:34985; % Index samples for second note
yy = y(index); % Extract indexed samples into yy
figure(1)
plot(index/Fs,yy) % Plot extracted waveform
xlabel('sec') ;    
ylabel('y(t)') ;
soundsc(yy,Fs) % Play extracted waveform


figure(3)
subplot(3,1,1)
stem(yy(1:1:end)), xlabel('n'), ylabel('y(n)') ;
ylim([-1,1]) ;      % set the range 
soundsc(y(1:1:end),Fs); % Play WAV file

subplot(3,1,2)
stem(yy(1:10:end)), xlabel('n'), ylabel('y(n)') ;
soundsc(y(1:10:end),Fs/10); % Play WAV file

subplot(3,1,3)
stem(yy(1:40:end)), xlabel('n'), ylabel('y(n)') ;
soundsc(y(1:40:end),Fs/40); % Play WAV file

%% 
r = audiorecorder(Fs,16,1); % Get recorder with Fs samples/sec, 16 bit, mono
record(r); pause            % Start speaking or singing after this line
stop(r);                    % Execute this line when you are done
mywav = getaudiodata(r,'double'); % Get sound
soundsc(mywav,Fs);                % Replay sound
figure
plot(mywav)


%%
lowpass = fir1(200,200/22050); % low-pass filter with cutoff 200 Hz
yylow = filter(lowpass,1,y); % filter signal
soundsc(yylow,Fs);pause; % play filtered signal, wait for keypress
bandpass = fir1(200,[200/22050 1000/22050],'DC-0'); % band-pass filter that passes 200-2000 Hz
yyband = filter(bandpass,1,y); % filter signal
soundsc(yyband,Fs);pause; % play filtered signal, wait for keypress
highpass = fir1(200,2000/22050,'DC-0'); % high-pass filter with cutoff 2000 Hz
yyhigh = filter(highpass,1,y); % filter signal
soundsc(yyhigh,Fs);pause; % play filtered signal, wait for keypress
soundsc(yylow+yyband+yyhigh,Fs);pause; % play the sum off all bands, await keypress
yyeq = yylow+4*yyband+yyhigh; % 3-band EQ for mid-range boost
soundsc(yyeq,Fs); % Play EQ with mid-range boost


%% 
soundsc(y,Fs); % Play WAV file
w = sin(2*pi*1000/Fs*[0:L-1]') ;
yy = y + w ;
soundsc(yy,Fs); % Play WAV file

figure
subplot(1,2,1)
Y = abs(fft(y)).^2 ;
plot([0:L/2]*Fs/L, Y(1:L/2+1)), xlabel('Hz');
subplot(1,2,2)
YY = abs(fft(yy)).^2 ; 
plot([0:L/2]*Fs/L, YY(1:L/2+1))/L, xlabel('Hz');


%%
soundsc(y,Fs); % Play WAV file
yy = atan(8*y);
soundsc(yy,Fs); % Play WAV file

%% 
w = sin(2*pi*1000/Fs*[0:L-1]') ;
yy = w .* y ;
soundsc(yy,Fs); % Play WAV file

figure(4)
subplot(3,1,1)
plot(y), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ;      % set the range 

subplot(3,1,2)
w = [zeros(floor(L/4),1); ones(floor(2*L/4),1); zeros(floor(L/4),1) ] ;
stem(w), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ;       % set the range 

subplot(3,1,3)
yyy = w .* y ;
plot(yyy), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ;      % set the range 

soundsc(yyy,Fs); % Play WAV file


%% 
figure(5)
subplot(2,1,1)
plot(y), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ;      % set the range 

subplot(2,1,2)
yy = [zeros(100000,1); y];
plot(yy), hold on, plot(zeros(100000,1),'r.','MarkerSize',5), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ;       % set the range 
soundsc(yy,Fs); % Play it


%% 
figure(6)
subplot(2,1,1)
plot(y), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ; 
subplot(2,1,2)
yy = y(100000:end);
plot(yy), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ; 
soundsc(yy,Fs); % Play it

%%
figure(7)
subplot(2,1,1)
plot(y), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ; 

subplot(2,1,2), hold off 
delay1 = round(Fs*0.8); % FIR Delay
coef = 0.7; % IIR Decay rate
yy = filter([1 zeros(1,delay1) coef],1,y);
plot(yy,'r'), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ;  
hold on;
plot(y,'b') 

soundsc(yy,Fs); % Play it




