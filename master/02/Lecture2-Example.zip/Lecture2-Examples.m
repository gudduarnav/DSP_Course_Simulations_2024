%%
% load handel.mat;

%%
[y,Fs] = audioread('guitar4.wav'); % Read WAV file
soundsc(y,Fs); % Play WAV file

%%
figure(1)
subplot(3,1,1)
plot(y), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ; 

subplot(3,1,2), hold off   
h = [1 2 3 4 5] ;
yy = conv(h,y);
plot(yy,'r'), xlabel('n'), ylabel('y[n]'), ylim([-1,1]) ;  
hold on;
plot(y,'b') 

soundsc(yy,Fs); % Play it


subplot(3,1,3),
x = 1 ; 
Est_h = conv(h,x);

stem([0:length(Est_h)-1],Est_h)


